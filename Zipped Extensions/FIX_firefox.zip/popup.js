document.getElementById('submit').addEventListener('click', function() {
    const url = document.getElementById('url').value;
    if (!url.endsWith('.png') && !url.endsWith('.png/')) {
        document.getElementById('message').textContent = 'Use a PNG image!';
    } else {
        browser.storage.local.set({avatarUrl: url}).then(function() {
            document.getElementById('message').textContent = 'URL saved!';
        });
    }
});

browser.runtime.onMessage.addListener((message) => {
    if (message.backgroundImage) {
        document.body.style.backgroundImage = "url('" + message.backgroundImage + "')";
        document.body.style.backgroundSize = "cover";
    }
});
